<?php
$cfg['blowfish_secret'] = 'HsiZzb.pnXo9Pt5]y&N7ZnK]cS}8~p7Y';